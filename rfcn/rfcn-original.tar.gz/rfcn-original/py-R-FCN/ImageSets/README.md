Please copy this folder to `$RFCN_ROOT/data/VOCdevkit0712/VOC0712`
