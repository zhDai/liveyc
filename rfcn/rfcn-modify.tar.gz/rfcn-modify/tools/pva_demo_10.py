# -*- coding: UTF-8 -*- 
#usr/bin/env python

# --------------------------------------------------------
# Faster R-CNN
# Copyright (c) 2015 Microsoft
# Licensed under The MIT License [see LICENSE for details]
# Written by Ross Girshick
# --------------------------------------------------------

"""
Demo script showing detections in sample images.

See README.md for installation instructions before running.
"""

import _init_paths
from fast_rcnn.config import cfg
from fast_rcnn.bbox_transform import clip_boxes, bbox_transform_inv
from fast_rcnn.test import _get_blobs
from fast_rcnn.nms_wrapper import nms
from utils.timer import Timer
import matplotlib.pyplot as plt
import numpy as np
import scipy.io as sio
import caffe, os, sys, cv2
import argparse
import matplotlib.pyplot as plt
import pylab

"""
CLASSES = ('__background__',#'1')
           'aeroplane', 'bicycle', 'bird', 'boat',
           'bottle', 'bus', 'car', 'cat', 'chair',
           'cow', 'diningtable', 'dog', 'horse',
           'electrombile', 'person', 'pottedplant',
           'sheep', 'sofa', 'train', 'tvmonitor')
"""

#CLASSES = ('__background__','car','person')
#CLASSES = ('__background__','electrombile','bicycle')
#CLASSES = ('__background__', 'car','person','electrombile','tricycle','bus','bicycle')
CLASSES = ('__background__', 'car','person','electrombile','tricycle','bus','bicycle','passengerbus','van','truck')
NETS = {'pvanet': ('test',
                  'test.model'),
        'zf': ('ZF',
                  'ZF_faster_rcnn_final.caffemodel')}

def change_im_detect(net, im, _t, boxes=None):
    _t['im_preproc'].tic()
    blobs, im_scales = _get_blobs(im, boxes)

    im_blob = blobs['data']
    blobs['im_info'] = np.array(
        [np.hstack((im_blob.shape[2], im_blob.shape[3], im_scales[0]))],
        dtype=np.float32)
    # reshape network inputs
    net.blobs['data'].reshape(*(blobs['data'].shape))
    net.blobs['im_info'].reshape(*(blobs['im_info'].shape))
	
	# do forward
    #forward_kwargs = {'data': blobs['data'].astype(np.float32, copy=False)}
	#forward_kwargs['im_info'] = blobs['im_info'].astype(np.float32, copy=False)

    # do forward
    net.blobs['data'].data[...] = blobs['data']
    #forward_kwargs = {'data': blobs['data'].astype(np.float32, copy=False)}
	
    net.blobs['im_info'].data[...] = blobs['im_info']
    
    _t['im_preproc'].toc()

    _t['im_net'].tic()
    blobs_out = net.forward()
    #print 'forward!'
    _t['im_net'].toc()
    #blobs_out = net.forward(**forward_kwargs)

    _t['im_postproc'].tic()
    
    assert len(im_scales) == 1, "Only single-image batch implemented"
    rois = net.blobs['rois'].data.copy()
    # unscale back to raw image space
    boxes = rois[:, 1:5] / im_scales[0]    

    scores = blobs_out['cls_prob']

    # Apply bounding-box regression deltas
    box_deltas = blobs_out['bbox_pred']
    #print box_deltas.shape
    pred_boxes = bbox_transform_inv(boxes, box_deltas)
    #print pred_boxes.shape  #400
    pred_boxes = clip_boxes(pred_boxes, im.shape)
    #print pred_boxes.shape  #400
    _t['im_postproc'].toc()

    #print scores, pred_boxes

    return scores, pred_boxes
				  
def vis_detections(ax, im, class_name, dets, thresh=0.5):
    """Draw detected bounding boxes."""
    inds = np.where(dets[:, -1] >= thresh)[0]
    if len(inds) == 0:
        return

    #im = im[:, :, (2, 1, 0)]
    #fig, ax = plt.subplots(figsize=(12, 12))
    #ax.imshow(im, aspect='equal')
    for i in inds:
        bbox = dets[i, :4]
        score = dets[i, -1]
	#print bbox[0], bbox[1],bbox[2], bbox[3]
        ax.add_patch(
            plt.Rectangle((bbox[0], bbox[1]),
                          bbox[2] - bbox[0],
                          bbox[3] - bbox[1], fill=False,
                          edgecolor='yellow', linewidth=1.0)
            )
    #   ax.text(bbox[0], bbox[1] - 2,
    #            '{:s} {:.3f}'.format(class_name, score),
    #            bbox=dict(facecolor='blue', alpha=0.5),
    #            fontsize=10, color='white')
        ax.text(bbox[0], bbox[1] - 2,
                '{:s} {:.3f}'.format(class_name, score),
                fontsize=10, color='blue')

    #ax.set_title(('{} detections with '
    #              'p({} | box) >= {:.1f}').format(class_name, class_name,
    #                                              thresh),
    #              fontsize=14)
    #plt.axis('off')
    #plt.tight_layout()
    #plt.draw()

def demo(net, image_name,path):
    """Detect object classes in an image using pre-computed object proposals."""

    # Load the demo image
    #im_file = os.path.join(cfg.DATA_DIR, 'demo', image_name)
    #im = cv2.imread(im_file)
    print image_name
    #print os.getcwd() 
    im=cv2.imread(path+'/{}'.format(image_name))
    #print im
    #cv2.namedWindow("Image")    
    #cv2.imshow("Image", im)
    #cv2.waitKey (0)    
    #cv2.destroyWindows("Image")  
    
    # Detect all object classes and regress object bounds
    timer = Timer()
    timer.tic()
    _t = {'im_preproc': Timer(), 'im_net' : Timer(), 'im_postproc': Timer(), 'misc' : Timer()}
    scores, boxes = change_im_detect(net, im, _t)

    timer.toc()
    print ('Detection took {:.3f}s for '
           '{:d} object proposals').format(timer.total_time, boxes.shape[0])
    print 'net {:.3f}s  preproc {:.3f}s  postproc {:.3f}s  misc {:.3f}s' \
              .format(_t['im_net'].average_time,
                      _t['im_preproc'].average_time, _t['im_postproc'].average_time,
                      _t['misc'].average_time)

    # Visualize detections for each class
    CONF_THRESH = 0.6
    NMS_THRESH = 0.3

    im = im[:, :, (2, 1, 0)]
    fig, ax = plt.subplots(figsize=(12, 12))
    ax.imshow(im, aspect='equal')

    for cls_ind, cls in enumerate(CLASSES[1:]):
	#print cls_ind,cls
        cls_ind += 1 # because we skipped background
        #cls_boxes = boxes[:, 4*cls_ind:4*(cls_ind + 1)]
        cls_boxes = boxes[:, 4:8]
        cls_scores = scores[:, cls_ind]
        dets = np.hstack((cls_boxes,
                          cls_scores[:, np.newaxis])).astype(np.float32)
        keep = nms(dets, NMS_THRESH)
	#keep = soft_nms(dets, method=cfg.TEST.SOFT_NMS)
        #keep = soft_nms(dets, method=1)
	#print keep
	#print "kepp:"+`keep`
        dets = dets[keep, :]
	#print dets
        vis_detections(ax, im, cls, dets, thresh=CONF_THRESH)

    plt.draw()

def parse_args():
    """Parse input arguments."""
    parser = argparse.ArgumentParser(description='pvanet demo')
    parser.add_argument('--gpu', dest='gpu_id', help='GPU device id to use [0]',
                        default=0, type=int)
    parser.add_argument('--cpu', dest='cpu_mode',
                        help='Use CPU mode (overrides --gpu)',
                        action='store_true')
    parser.add_argument('--net', dest='pvanet', help='Network to use [vgg16]',
                        choices=NETS.keys(), default='pvanet')

    args = parser.parse_args()

    return args

def vis_square(data):

    # 输入的数据为一个ndarray，尺寸可以为(n, height, width)或者是 (n, height, width, 3)
    # 前者即为n个灰度图像的数据，后者为n个rgb图像的数据
    # 在一个sqrt(n) by sqrt(n)的格子中，显示每一幅图像

    # 对输入的图像进行normlization
    data = (data - data.min()) / (data.max() - data.min())

    # 强制性地使输入的图像个数为平方数，不足平方数时，手动添加几幅
    n = int(np.ceil(np.sqrt(data.shape[0])))
    # 每幅小图像之间加入小空隙
    padding = (((0, n ** 2 - data.shape[0]),
               (0, 1), (0, 1))                 # add some space between filters
                           + ((0, 0),) * (data.ndim - 3))  # don't pad the last dimension (if there is one)
    data = np.pad(data, padding, mode='constant', constant_values=1)  # pad with ones (white)   

    # 将所有输入的data图像平复在一个ndarray-data中（tile the filters into an image）
    data = data.reshape((n, n) + data.shape[1:]).transpose((0, 2, 1, 3) + tuple(range(4, data.ndim + 1)))
    # data的一个小例子,e.g., (3,120,120)
    # 即，这里的data是一个2d 或者 3d 的ndarray
    data = data.reshape((n * data.shape[1], n * data.shape[3]) + data.shape[4:])
    #plt.savefig("filename.png")
    # 显示data所对应的图像
    plt.imshow(data)
    pylab.show()  
    plt.axis('off')

if __name__ == '__main__':
    cfg.TEST.HAS_RPN = True  # Use RPN for proposals

    args = parse_args()

    print args

    # timers
    _t = {'im_preproc': Timer(), 'im_net' : Timer(), 'im_postproc': Timer(), 'misc' : Timer()}

    #prototxt = os.path.join(cfg.MODELS_DIR, #NETS[args.pvanet][0],
    #                        'comp', 'test.pt')
    solver_sub_path='lite'
    pt_name='original_test.pt'
    #pt_name='original_test.pt'
    #model_name='pvanet_frcnn_21cls_iter_10000.caffemodel'
    model_name='original_690K.model'
#    prototxt = os.path.join('{}/pva-faster-rcnn/models/pvanet'.format(os.environ['HOME']),
#                            '{}/'.format(solver_sub_path), pt_name)
    #caffemodel = os.path.join('{}/pva-faster-rcnn/output/faster_rcnn_pvanet'.format(os.environ['HOME']),
	#		      'my_model', model_name)
#    caffemodel = os.path.join('{}/pva-faster-rcnn/models/pvanet'.format(os.environ['HOME']),
#			      'lite', model_name)

    #prototxt = "/home/dzh/Documents/py-R-FCN/models/rfcn_pvanet/test_agnostic_c.prototxt"
    #prototxt = "/home/dzh/Documents/py-R-FCN/models/rfcn_pvanet/test_agnostic_4.prototxt"
    #prototxt = "/home/dzh/Documents/py-R-FCN/models/rfcn_pvanet/test_agnostic_big.prototxt"
    #prototxt = "/home/dzh/Documents/py-R-FCN/compress_bn/test_agnostic_4_inference.prototxt"
    #prototxt = "/home/dzh/test_agnostic_8.prototxt"
    prototxt = "/home/dzh/Documents/py-R-FCN/models/rfcn_pvanet/test_agnostic_8.prototxt"

    #caffemodel = "/home/dzh/Documents/py-R-FCN/output/rfcn_end2end_ohem_newdata_18w/voc_2007_trainval/rfcn_pvanet_lite_dzh_6_1_ohem_iter_180000.caffemodel"
    caffemodel = "/home/dzh/Documents/py-R-FCN/output/rfcn_end2end_ohem/voc_2007_trainval/rfcn_pvanet_lite_dzh_6_5_ohem_iter_950000.caffemodel"
    #caffemodel = "/home/dzh/Documents/py-R-FCN/output/rfcn_end2end_ohem_73w/voc_2007_trainval/rfcn_pvanet_lite_dzh_5_25_ohem_iter_730000.caffemodel"
    #caffemodel = "/home/dzh/Documents/py-R-FCN/output/rfcn_end2end_ohem_10w_big/voc_2007_trainval/rfcn_pvanet_lite_dzh_5_25_ohem_iter_100000.caffemodel"
    #caffemodel = "/home/dzh/Documents/py-R-FCN/output/rfcn_end2end_ohem_newdata_18w/voc_2007_trainval/rfcn_pvanet_lite_dzh_6_1_ohem_iter_30000.caffemodel"
    #caffemodel = "/home/dzh/Documents/py-R-FCN/output/rfcn_end2end_ohem_73w_6_14/voc_2007_trainval/rfcn_pvanet_lite_dzh_6_5_ohem_iter_730000.caffemodel"
    #caffemodel = "/home/dzh/rfcn_pvanet_lite_dzh_6_8_ohem_iter_1540000.caffemodel"
    #caffemodel = "/home/dzh/rfcn_pvanet_lite_dzh_6_8_ohem_iter_1840000.caffemodel"
    	
    


    if not os.path.isfile(caffemodel):
        raise IOError(('{:s} not found.\nDid you run').format(caffemodel))

    if args.cpu_mode:
        caffe.set_mode_cpu()
    else:
        caffe.set_mode_gpu()
        caffe.set_device(args.gpu_id)
        cfg.GPU_ID = args.gpu_id
    net = caffe.Net(prototxt, caffemodel, caffe.TEST)
    #feat = net.blobs['conv1'].data[0, :36]
    print '\n\nLoaded network {:s}'.format(caffemodel)


    #im_names =['000001.jpg','000002.jpg','000003.jpg','000004.jpg','000005.jpg','000006.jpg','000007.jpg','000008.jpg','000009.jpg','000010.jpg','000011.jpg','000012.jpg']
    path="./test_image_9/"
    #path="/home/dzh/Downloads/new_bicycle"
    #path="/home/dzh/Downloads/new_passangebus"
    im_names = os.listdir(path) 

    for im_name in im_names:
        print '~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~'
        print 'Demo for {}'.format(im_name)
        demo(net, im_name,path)
        #feat = net.blobs['conv3'].data[0, 1:2]
        #feat = net.blobs['convf'].data[0,:2]
    	#vis_square(feat)

    plt.show()

