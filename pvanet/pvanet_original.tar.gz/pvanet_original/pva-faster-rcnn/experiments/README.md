Scripts are under `experiments/scripts`.

Each script saves a log file under `experiments/logs`.

Configuration override files used in the experiments are stored in `experiments/cfgs`.
