#/bin/bash
wget https://www.dropbox.com/s/38g96yh51afzj7c/test_690K.model?dl=0 -O models/pvanet/lite/test.model
wget https://www.dropbox.com/s/4j27cjkv5t7danz/original_690K.model?dl=0 -O models/pvanet/lite/original.model
