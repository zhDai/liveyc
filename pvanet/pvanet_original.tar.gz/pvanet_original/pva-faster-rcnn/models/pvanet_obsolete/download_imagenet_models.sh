#/bin/bash
wget https://www.dropbox.com/s/2xsfg8vqmhv9p84/test.model?dl=0 -O models/pvanet/imagenet/test.model
wget https://www.dropbox.com/s/l11v2uh05pjejws/original.model?dl=0 -O models/pvanet/imagenet/original.model
