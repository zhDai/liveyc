#/bin/bash
wget https://www.dropbox.com/s/87zu4y6cvgeu8vs/test.model?dl=0 -O models/pvanet/full/test.model
wget https://www.dropbox.com/s/aphfzyc9plg5mvx/test.model?dl=0 -O models/pvanet/comp/test.model
