#/bin/bash
wget https://www.dropbox.com/s/v7ccvm61q5htxha/original.model?dl=0 -O models/pvanet/full/original.model
wget https://www.dropbox.com/s/eqokl27ohk6au51/original.model?dl=0 -O models/pvanet/comp/original.model
