#/bin/bash
# ImageNet pre-trained
wget https://www.dropbox.com/s/a2y0e12kmu8wjsf/pva9.1_preAct_train_iter_1900000.caffemodel?dl=1 -O models/pvanet/pretrained/pva9.1_preAct_train_iter_1900000.caffemodel