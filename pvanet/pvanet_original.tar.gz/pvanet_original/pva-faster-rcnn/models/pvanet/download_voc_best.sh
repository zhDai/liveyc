#/bin/bash
# COCO train/val + VOC0712 train/val + VOC07 test
wget https://www.dropbox.com/s/m65ioxcguevsacc/PVA9.1_ImgNet_COCO_VOC0712plus.caffemodel?dl=1 -O models/pvanet/pva9.1/PVA9.1_ImgNet_COCO_VOC0712plus.caffemodel